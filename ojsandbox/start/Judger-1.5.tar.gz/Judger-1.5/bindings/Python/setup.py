# coding=utf-8
from distutils.core import setup, Extension

setup(name='_judger',
      version='2.1',
      packages=["_judger"])