#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("abs %d", abs(-1024));
    return 0;
}