#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    string s;
    cin >> s;
    cout << s;
    return 0;
}