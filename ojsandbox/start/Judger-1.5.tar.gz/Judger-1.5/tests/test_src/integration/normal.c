#include <stdio.h>
#include <string.h>

int main()
{
    char input[100];
    scanf("%s", input);
    printf("%s\n", input);
    printf("Hello world");
    return 0;
}