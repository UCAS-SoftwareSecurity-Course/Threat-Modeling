<script setup lang="ts">
console.log('[App.vue]', `Electron ${process.versions.electron}!`)
</script>

<template>
  <router-view />
</template>

