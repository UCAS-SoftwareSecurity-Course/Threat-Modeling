#ifndef _TVM_TOKENS_H_
#define _TVM_TOKENS_H_

#define TOK_INCLUDE "%include"
#define TOK_DEFINE "%define"

extern const char *tvm_opcode_map[];

extern const char *tvm_register_map[];

#endif
