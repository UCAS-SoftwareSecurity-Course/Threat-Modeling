package top.guoziyang.mydb.backend.parser.statement;

public class Select {
    public String tableName;
    public String[] fields;
    public Where where;
}
