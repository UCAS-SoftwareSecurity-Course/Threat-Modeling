package top.guoziyang.mydb.backend.utils;

public class ParseStringRes {
    public String str;
    public int next;

    public ParseStringRes(String str, int next) {
        this.str = str;
        this.next = next;
    }
}
