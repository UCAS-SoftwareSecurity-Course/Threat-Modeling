package top.guoziyang.mydb.backend.parser.statement;

public class Create {
    public String tableName;
    public String[] fieldName;
    public String[] fieldType;
    public String[] index;
}
