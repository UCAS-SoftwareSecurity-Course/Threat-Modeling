package top.guoziyang.mydb.backend.parser.statement;

public class Update {
    public String tableName;
    public String fieldName;
    public String value;
    public Where where;
}
