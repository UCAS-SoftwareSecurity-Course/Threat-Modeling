export const expressions=[
  {title:"[微笑]",url: "/微笑.gif"},
  {title:"[撇嘴]",url: "/撇嘴.gif"},
  {title:"[色]",url: "/色.gif"},
  {title:"[发呆]",url: "/发呆.gif"},
  {title:"[得意]",url: "/得意.gif"},
  {title:"[流泪]",url: "/流泪.gif"},
  {title:"[害羞]",url: "/害羞.gif"},
  {title:"[闭嘴]",url: "/闭嘴.gif"},
  {title:"[睡]",url: "/睡.gif"},
  {title:"[大哭]",url: "/大哭.gif"},
  {title:"[尴尬]",url: "/尴尬.gif"},
  {title:"[呲牙]",url: "/呲牙.gif"},
  {title:"[发怒]",url: "/发怒.gif"},
  {title:"[调皮]",url: "/调皮.gif"},
  {title:"[惊讶]",url: "/惊讶.gif"},
  {title:"[难过]",url: "/难过.gif"},
  {title:"[酷]",url: "/酷.gif"},
  {title:"[冷汗]",url: "/冷汗.gif"},
  {title:"[抓狂]",url: "/抓狂.gif"},
  {title:"[吐]",url: "/吐.gif"},
  {title:"[偷笑]",url: "/偷笑.gif"},
  {title:"[可爱]",url: "/可爱.gif"},
  {title:"[白眼]",url: "/白眼.gif"},
  {title:"[傲慢]",url: "/傲慢.gif"},
  {title:"[饥饿]",url: "/饥饿.gif"},
  {title:"[困]",url: "/困.gif"},
  {title:"[惊恐]",url: "/惊恐.gif"},
  {title:"[流汗]",url: "/流汗.gif"},
  {title:"[憨笑]",url: "/憨笑.gif"},
  {title:"[大兵]",url: "/大兵.gif"},
  {title:"[奋斗]",url: "/奋斗.gif"},
  {title:"[咒骂]",url: "/咒骂.gif"},
  {title:"[疑问]",url: "/疑问.gif"},
  {title:"[嘘]",url: "/嘘.gif"},
  {title:"[晕]",url: "/晕.gif"},
  {title:"[折磨]",url: "/折磨.gif"},
  {title:"[衰]",url: "/衰.gif"},
  {title:"[骷髅]",url: "/骷髅.gif"},
  {title:"[敲打]",url: "/敲打.gif"},
  {title:"[再见]",url: "/再见.gif"},
  {title:"[擦汗]",url: "/擦汗.gif"},
  {title:"[抠鼻]",url: "/抠鼻.gif"},
  {title:"[鼓掌]",url: "/鼓掌.gif"},
  {title:"[嗅大了]",url: "/嗅大了.gif"},
  {title:"[坏笑]",url: "/坏笑.gif"},
  {title:"[左哼哼]",url: "/左哼哼.gif"},
  {title:"[右哼哼]",url: "/右哼哼.gif"},
  {title:"[哈欠]",url: "/哈欠.gif"},
  {title:"[鄙视]",url: "/鄙视.gif"},
  {title:"[委屈]",url: "/委屈.gif"},
  {title:"[可怜]",url: "/可怜.gif"},
  {title:"[阴险]",url: "/阴险.gif"},
  {title:"[亲亲]",url: "/亲亲.gif"},
  {title:"[吓]",url: "/吓.gif"},
  {title:"[快哭了]",url: "/快哭了.gif"},
  {title:"[菜刀]",url: "/菜刀.gif"},
  {title:"[西瓜]",url: "/西瓜.gif"},
  {title:"[啤酒]",url: "/啤酒.gif"},
  {title:"[篮球]",url: "/篮球.gif"},
  {title:"[乒乓]",url: "/乒乓.gif"},
  {title:"[咖啡]",url: "/咖啡.gif"},
  {title:"[饭]",url: "/饭.gif"},
  {title:"[猪头]",url: "/猪头.gif"},
  {title:"[玫瑰]",url: "/玫瑰.gif"},
  {title:"[凋谢]",url: "/凋谢.gif"},
  {title:"[心]",url: "/心.gif"},
  {title:"[心碎]",url: "/心碎.gif"},
  {title:"[蛋糕]",url: "/蛋糕.gif"},
  {title:"[闪电]",url: "/闪电.gif"},
  {title:"[炸弹]",url: "/炸弹.gif"},
  {title:"[刀]",url: "/刀.gif"},
  {title:"[足球]",url: "/足球.gif"},
  {title:"[瓢虫]",url: "/瓢虫.gif"},
  {title:"[便便]",url: "/便便.gif"},
  {title:"[夜晚]",url: "/夜晚.gif"},
  {title:"[太阳]",url: "/太阳.gif"},
  {title:"[礼物]",url: "/礼物.gif"},
  {title:"[拥抱]",url: "/拥抱.gif"},
  {title:"[强]",url: "/强.gif"},
  {title:"[弱]",url: "/弱.gif"},
  {title:"[握手]",url: "/握手.gif"},
  {title:"[胜利]",url: "/胜利.gif"},
  {title:"[抱拳]",url: "/抱拳.gif"},
  {title:"[勾引]",url: "/勾引.gif"},
  {title:"[拳头]",url: "/拳头.gif"},
  {title:"[差劲]",url: "/差劲.gif"},
  {title:"[爱你]",url: "/爱你.gif"},
  {title:"[NO]",url: "/NO.gif"},
  {title:"[OK]",url: "/OK.gif"},
  {title:"[爱情]",url: "/爱情.gif"},
  {title:"[飞吻]",url: "/飞吻.gif"},
  {title:"[发财]",url: "/发财.gif"},
  {title:"[帅]",url: "/帅.gif"},
  {title:"[雨伞]",url: "/雨伞.gif"},
  {title:"[高铁左车头]",url: "/高铁左车头.gif"},
  {title:"[车厢]",url: "/车厢.gif"},
  {title:"[高铁右车头]",url: "/高铁右车头.gif"},
  {title:"[纸巾]",url: "/纸巾.gif"},
  {title:"[右太极]",url: "/右太极.gif"},
  {title:"[左太极]",url: "/左太极.gif"},
  {title:"[献吻]",url: "/献吻.gif"},
  {title:"[街舞]",url: "/街舞.gif"},
  {title:"[激动]",url: "/激动.gif"},
  {title:"[挥动]",url: "/挥动.gif"},
  {title:"[跳绳]",url: "/跳绳.gif"},
  {title:"[回头]",url: "/回头.gif"},
  {title:"[磕头]",url: "/磕头.gif"},
  {title:"[转圈]",url: "/转圈.gif"},
  {title:"[怄火]",url: "/怄火.gif"},
  {title:"[发抖]",url: "/发抖.gif"},
  {title:"[跳跳]",url: "/跳跳.gif"},
  {title:"[爆筋]",url: "/爆筋.gif"},
  {title:"[沙发]",url: "/沙发.gif"},
  {title:"[钱]",url: "/钱.gif"},
  {title:"[蜡烛]",url: "/蜡烛.gif"},
  {title:"[枪]",url: "/枪.gif"},
  {title:"[灯]",url: "/灯.gif"},
  {title:"[香蕉]",url: "/香蕉.gif"},
  {title:"[吻]",url: "/吻.gif"},
  {title:"[下雨]",url: "/下雨.gif"},
  {title:"[闹钟]",url: "/闹钟.gif"},
  {title:"[囍]",url: "/囍.gif"},
  {title:"[棒棒糖]",url: "/棒棒糖.gif"},
  {title:"[面条]",url: "/面条.gif"},
  {title:"[车]",url: "/车.gif"},
  {title:"[邮件]",url: "/邮件.gif"},
  {title:"[风车]",url: "/风车.gif"},
  {title:"[药丸]",url: "/药丸.gif"},
  {title:"[奶瓶]",url: "/奶瓶.gif"},
  {title:"[灯笼]",url: "/灯笼.gif"},
  {title:"[青蛙]",url: "/青蛙.gif"},
  {title:"[戒指]",url: "/戒指.gif"},
  {title:"[K歌]",url: "/K歌.gif"},
  {title:"[熊猫]",url: "/熊猫.gif"},
  {title:"[喝彩]",url: "/喝彩.gif"},
  {title:"[购物]",url: "/购物.gif"},
  {title:"[多云]",url: "/多云.gif"},
  {title:"[鞭炮]",url: "/鞭炮.gif"},
  {title:"[飞机]",url: "/飞机.gif"},
  {title:"[气球]",url: "/气球.gif"}
];
export const highlightKeyword=(reg,str) => {
  let curIndex = 0, list = [], result = {};
  while ((result = reg.exec(str))){
    list.push(str.slice(curIndex,result.index))
    list.push(result[0])
    curIndex = result.index + result[0].length
  }
  if(str.length > curIndex){
    list.push(str.slice(curIndex,str.length))
  }
  return list
}
export const renderEmoji=(text,baseUrl,h)=>{
  let emojiMap={};
  expressions.forEach((item)=>{
    emojiMap[item.title]=item.url;
  });
  const reg=/\[.*?\]/g;
  let arr=highlightKeyword(reg,text);
  return h('div',
    arr.map((item)=>{
      if(reg.test(item)&&emojiMap[item]){
        return h('img',{
          class:"emoji-img",
          attrs:{
            src:baseUrl+emojiMap[item]
          }
        })
      }else {
        return item;
      }
    })
  )
};
export const getDeviceType=(userAgent)=>{
  userAgent=userAgent.toLowerCase();
  let bIsIpad = userAgent.match(/ipad/i)== "ipad";
  let bIsIphoneOs = userAgent.match(/iphone os/i)== "iphone os";
  let bIsMidp = userAgent.match(/midp/i)== "midp";
  let bIsUc7 = userAgent.match(/rv:1.2.3.4/i)== "rv:1.2.3.4";
  let bIsUc = userAgent.match(/ucweb/i)== "ucweb";
  let bIsAndroid = userAgent.match(/android/i)== "android";
  let bIsCE = userAgent.match(/windows ce/i)== "windows ce";
  let bIsWM = userAgent.match(/windows mobile/i)== "windows mobile";
  if (bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
    return "phone";
  } else {
    return "pc";
  }
};
