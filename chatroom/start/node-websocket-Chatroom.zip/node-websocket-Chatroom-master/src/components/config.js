export const BASE_URL = process.env.BASE_URL
export const BELL_URL = BASE_URL+'static/8400.mp3'
export const EMOJI_BASE_URL = BASE_URL+'static/img/emoji'
