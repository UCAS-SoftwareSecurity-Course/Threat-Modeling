<template>
  <div class="app-warp">
    <ChatApp></ChatApp>
  </div>
</template>

<script>
import ChatApp from "./components/ChatApp";
export default {
  name: 'App',
  components: {
    ChatApp
  }
}
</script>

<style scoped lang="less">

</style>
